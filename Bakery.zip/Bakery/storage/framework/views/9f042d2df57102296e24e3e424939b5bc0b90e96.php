<?php $__env->startSection('title', 'Fast Foods'); ?>

<?php $__env->startSection('content'); ?>

    <h1>TOP BAKERY</h1>
    <h2>Fast Foods</h2>
    <p>
    	This is where all the pictures and prices go
    </p>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>