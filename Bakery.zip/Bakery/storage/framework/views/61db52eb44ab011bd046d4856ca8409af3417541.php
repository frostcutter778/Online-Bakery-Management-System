<?php $__env->startSection('title', 'Chocolates & Sweets'); ?>

<?php $__env->startSection('content'); ?>

    <h1>TOP BAKERY</h1>
    <h2>Chocolates & Sweets</h2>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>